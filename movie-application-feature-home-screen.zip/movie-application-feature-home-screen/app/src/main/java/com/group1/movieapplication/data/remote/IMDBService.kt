package com.group1.movieapplication.data.remote

import com.group1.movieapplication.model.IMDBPopularResponse
import com.group1.movieapplication.model.movieDetail.IMDBMovieResponse
import com.group1.movieapplication.model.movieDetail.IMDBTrailerResponse
import com.group1.movieapplication.model.upcoming.IMDBUpcomingResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Url

interface IMDBService {
    @GET("MostPopularMovies/k_70m0dwp1")
    suspend fun getPopularMovies(): Response<IMDBPopularResponse>

    @GET("MostPopularTVs/k_70m0dwp1")
    suspend fun getPopularTVs(): Response<IMDBPopularResponse>

    @GET("ComingSoon/k_70m0dwp1")
    suspend fun getUpcomingMovies(): Response<IMDBUpcomingResponse>

    @GET
    suspend fun getMovieById(@Url url : String) : IMDBMovieResponse

    @GET
    suspend fun getMovieTrailer(@Url url : String) : IMDBTrailerResponse


}