package com.group1.movieapplication.ui.home.adapter

import com.group1.movieapplication.model.PopularItem

interface PopularItemOnClickListener {
    fun onClick(popularItem: PopularItem)
}