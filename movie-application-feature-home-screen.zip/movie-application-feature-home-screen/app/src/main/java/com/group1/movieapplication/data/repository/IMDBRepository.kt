package com.group1.movieapplication.data.repository

import com.group1.movieapplication.model.IMDBPopularResponse
import com.group1.movieapplication.model.movieDetail.IMDBMovieResponse
import com.group1.movieapplication.model.movieDetail.IMDBTrailerResponse
import com.group1.movieapplication.model.upcoming.IMDBUpcomingResponse
import com.group1.movieapplication.utils.NetworkResult
import retrofit2.http.Url

interface IMDBRepository {
    suspend fun getPopularMovies(): NetworkResult<IMDBPopularResponse>
    suspend fun getPopularTVs(): NetworkResult<IMDBPopularResponse>
    suspend fun getUpcoming(): NetworkResult<IMDBUpcomingResponse>
    suspend fun getMovieById(@Url url : String) : IMDBMovieResponse
    suspend fun getMovieTrailer(@Url url : String) : IMDBTrailerResponse
}