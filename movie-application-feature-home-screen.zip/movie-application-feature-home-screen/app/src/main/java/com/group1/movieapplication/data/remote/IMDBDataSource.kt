package com.group1.movieapplication.data.remote

import retrofit2.http.Url
import javax.inject.Inject

class IMDBDataSource @Inject constructor(
    private val service: IMDBService
) {
    suspend fun getPopularMovies() = service.getPopularMovies()

    suspend fun getPopularTVs() = service.getPopularTVs()

    suspend fun getUpcoming() = service.getUpcomingMovies()

    suspend fun getMovieById(@Url url : String) = service.getMovieById(url)

    suspend fun getMovieTrailer(@Url url : String) = service.getMovieTrailer(url)
}