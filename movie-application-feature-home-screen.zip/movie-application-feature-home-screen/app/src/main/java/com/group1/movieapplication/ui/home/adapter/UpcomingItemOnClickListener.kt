package com.group1.movieapplication.ui.home.adapter

import com.group1.movieapplication.model.upcoming.UpComingItem

interface UpcomingItemOnClickListener {
    fun onClick(upComingItem: UpComingItem)
}