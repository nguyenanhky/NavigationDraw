package com.group1.movieapplication.ui.profile

import android.app.Application
import android.content.res.Resources
import androidx.lifecycle.*
import com.group1.movieapplication.data.repository.FirebaseAuthRepository
import com.group1.movieapplication.data.repository.FirebaseRTDBRepository
import com.group1.movieapplication.data.repository.IMDBRepository

import com.group1.movieapplication.model.User
import com.group1.movieapplication.model.movieDetail.IMDBMovieResponse
import com.group1.movieapplication.model.movieDetail.Movie
import com.group1.movieapplication.model.movieDetail.MovieImg
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import timber.log.Timber
import javax.inject.Inject


@HiltViewModel
class ProfileViewModel @Inject constructor(val imdbRepository: IMDBRepository): ViewModel() {
    val firebaseAuthRepository = FirebaseAuthRepository()
    val firebaseRTDBRepository = FirebaseRTDBRepository()
    val movieList = MutableLiveData<ArrayList<IMDBMovieResponse>>()
    var ratedMovieIDList = MutableLiveData<ArrayList<String>>()


    fun isLogined(){
        viewModelScope.launch(Dispatchers.IO) {
            firebaseAuthRepository.isLogined()
        }
    }

    fun getUserInfo():MutableLiveData<User>{
        return firebaseAuthRepository.getUserInfo()
    }


    fun getRatedMovieIdList(): MutableLiveData<ArrayList<String>> {
     return firebaseRTDBRepository.getMyMovieID()
    }

    fun getMovieImgList(movieIdList : ArrayList<String>){
        viewModelScope.launch {
            val content = ArrayList<IMDBMovieResponse>()
           try {
               coroutineScope {
                   val respones = movieIdList.forEach{ id ->
                       val url = "https://imdb-api.com/en/API/Title/k_70m0dwp1/${id}"
                       val apiCaller = async { imdbRepository.getMovieById(url) }
                       val response = apiCaller.await()
                       content.add(response)
                       movieList.postValue(content)
                   }
               }
           }
           catch (e: Exception){
               Timber.d(e)
           }
        }
    }
}