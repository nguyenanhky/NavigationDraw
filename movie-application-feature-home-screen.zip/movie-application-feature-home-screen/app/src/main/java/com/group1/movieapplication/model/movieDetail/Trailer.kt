package com.group1.movieapplication.model.movieDetail

class Trailer(trailerUrl : String) {
    var trailerUrl : String? = trailerUrl
}