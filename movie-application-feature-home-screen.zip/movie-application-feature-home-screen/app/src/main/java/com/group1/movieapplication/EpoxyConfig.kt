package com.group1.movieapplication

import com.airbnb.epoxy.EpoxyDataBindingPattern

@EpoxyDataBindingPattern(layoutPrefix = "item", rClass = R::class)
interface EpoxyConfig { }