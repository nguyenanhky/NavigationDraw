package com.example.searchmovie.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;

import com.example.searchmovie.R;
import com.example.searchmovie.adapters.TVSearchAdapter;
import com.example.searchmovie.adapters.TVShowsAdapter;
import com.example.searchmovie.databinding.ActivitySearchBinding;
import com.example.searchmovie.models.TVsearch;
import com.example.searchmovie.models.TVshow;
import com.example.searchmovie.viewmodels.SearchViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class SearchActivity extends AppCompatActivity {

    private ActivitySearchBinding activitySearchBinding;
    private SearchViewModel viewModel;
    private List<TVsearch> tVshows = new ArrayList<>();
    private TVSearchAdapter tvShowsAdapter;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activitySearchBinding = DataBindingUtil.setContentView(this, R.layout.activity_search);
        doInitialization();
    }

    private void doInitialization() {
        activitySearchBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        activitySearchBinding.tvShowsRecyclerview.setHasFixedSize(true);
        viewModel = new ViewModelProvider(this).get(SearchViewModel.class);
        //*
        tvShowsAdapter = new TVSearchAdapter(tVshows);
        activitySearchBinding.tvShowsRecyclerview.setAdapter(tvShowsAdapter);

        activitySearchBinding.inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (timer != null) {
                    timer.cancel();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!editable.toString().trim().isEmpty()) {
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    searchTVShow(editable.toString());
                                }
                            });
                        }
                    }, 800);
                } else {
                    tVshows.clear();
                    tvShowsAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void searchTVShow(String query) {
        viewModel.searchTVShow(query).observe(this, tvSearchResponse -> {
            if (tvSearchResponse != null) {
                if (tvSearchResponse.getSearchitem()!= null) {
                    int oldCount = tVshows.size();
                    tVshows.addAll(tvSearchResponse.getSearchitem());
                    tvShowsAdapter.notifyItemRangeInserted(oldCount, tVshows.size());
                }
            }
        });
    }
}


