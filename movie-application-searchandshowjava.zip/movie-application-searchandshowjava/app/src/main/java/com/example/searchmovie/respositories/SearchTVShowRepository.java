package com.example.searchmovie.respositories;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.searchmovie.netword.ApiClient;
import com.example.searchmovie.netword.ApiService;
import com.example.searchmovie.response.TVSearchResponse;
import com.example.searchmovie.response.TVSearchResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchTVShowRepository {
    private ApiService apiService;

    public SearchTVShowRepository() {
        apiService = ApiClient.getRetrofit().create(ApiService.class);
    }

    public LiveData<TVSearchResponse> searchTVShow(String query){
        MutableLiveData<TVSearchResponse>data = new MutableLiveData<>();
        apiService.searchTVShow(query).enqueue(new Callback<TVSearchResponse>() {
            @Override
            public void onResponse(@NonNull Call<TVSearchResponse> call,@NonNull Response<TVSearchResponse> response) {
                data.setValue(response.body());
            }

            @Override
            public void onFailure(@NonNull Call<TVSearchResponse> call,@NonNull Throwable t) {
                data.setValue(null);
            }
        });
        return data;
    }

//    public LiveData<TVSearchResponse> searchTVShow(){
//        MutableLiveData<TVSearchResponse>data = new MutableLiveData<>();
//        apiService.searchTVShow().enqueue(new Callback<TVSearchResponse>() {
//            @Override
//            public void onResponse(@NonNull Call<TVSearchResponse> call,@NonNull Response<TVSearchResponse> response) {
//                data.setValue(response.body());
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<TVSearchResponse> call,@NonNull Throwable t) {
//                data.setValue(null);
//            }
//        });
//        return data;
//    }
}
