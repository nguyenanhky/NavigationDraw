package com.example.searchmovie.response;

import com.example.searchmovie.models.TVshow;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TVShowResponse {
    @SerializedName("errorMessage")
    private String errorMessage;

    @SerializedName("items")
    private List<TVshow> popularItems;

    public String getErrorMessage() {
        return errorMessage;
    }

    public List<TVshow> getPopularItems() {
        return popularItems;
    }
}
