package com.example.searchmovie.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;

import com.example.searchmovie.R;
import com.example.searchmovie.adapters.TVShowsAdapter;
import com.example.searchmovie.databinding.ActivityMainBinding;
import com.example.searchmovie.models.TVshow;
import com.example.searchmovie.viewmodels.MostPopularTVShowsViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private MostPopularTVShowsViewModel viewModel;
    private ActivityMainBinding activityMainBinding;
    private List<TVshow> tVshows = new ArrayList<>();
    private TVShowsAdapter tvShowsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        doInitialization();

    }

    private void doInitialization() {
        activityMainBinding.tvShowsRecyclerview.setHasFixedSize(true);
        viewModel = new ViewModelProvider(this).get(MostPopularTVShowsViewModel.class);
        tvShowsAdapter = new TVShowsAdapter(tVshows);
        activityMainBinding.tvShowsRecyclerview.setAdapter(tvShowsAdapter);

        // search
        activityMainBinding.imageSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SearchActivity.class));
            }
        });

        getMostPopularTVShows();

    }

    private void getMostPopularTVShows() {

        viewModel.getMostPopularTVShows().observe(this, mosTvShowResponse -> {
            if (mosTvShowResponse != null) {
                if (mosTvShowResponse.getPopularItems()!= null) {
                    int oldcount = tVshows.size();
                    tVshows.addAll(mosTvShowResponse.getPopularItems());
                   tvShowsAdapter.notifyItemRangeInserted(oldcount,tVshows.size());
                }
            }
        });
    }

}