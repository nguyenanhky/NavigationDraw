package com.example.searchmovie.models;

import com.google.gson.annotations.SerializedName;

public class TVsearch {
    @SerializedName("id")
    private String id;

    @SerializedName("resultType")
    private String resultType;

    @SerializedName("image")
    private String image;

    @SerializedName("title")
    private String title;

    @SerializedName("description")
    private String description;

    public String getId() {
        return id;
    }

    public String getResultType() {
        return resultType;
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
