package com.example.searchmovie.models;

public class Episode {
}
