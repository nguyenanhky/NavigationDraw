package com.example.searchmovie.netword;

import com.example.searchmovie.models.TVshow;
import com.example.searchmovie.response.TVSearchResponse;
import com.example.searchmovie.response.TVShowResponse;


import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
//    @GET("most-popular")
//    Call<TVShowResponse> getMostPopularTVshow(@Query("page") int page);
//
////    @GET("search")
////    Call<TVShowResponse>searchTVShow(@Query("q") String query,@Query("page") int page);
//
//    @GET("search?q=arrow&page=1")
//    Call<TVShowResponse>searchTVShow();

    @GET("MostPopularMovies/k_t1wmg05t")
    Call<TVShowResponse> getMostPopularTVshow();
//    // chu ý
//    @GET("SearchMovie/k_t1wmg05t/{title}")
//    Call<TVSearchResponse> searchTVShow(@Path("titlle") String title);

    @GET("SearchMovie/k_t1wmg05t/{title}")
    Call<TVSearchResponse> searchTVShow(@Path(value = "title",encoded = true) String title);
}
