package com.example.searchmovie.response;

import com.example.searchmovie.models.TVsearch;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TVSearchResponse {
    @SerializedName("searchType")
    private String searchType;

    @SerializedName("expression")
    private String expression;

    @SerializedName("results")
    private List<TVsearch> searchitem;

    @SerializedName("errorMessage")
    private String errorMessage;

    public String getSearchType() {
        return searchType;
    }

    public String getExpression() {
        return expression;
    }

    public List<TVsearch> getSearchitem() {
        return searchitem;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
