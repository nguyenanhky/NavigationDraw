package com.example.searchmovie.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.searchmovie.R;
import com.example.searchmovie.databinding.ItemSearchTvBinding;
import com.example.searchmovie.models.TVsearch;

import java.util.List;

public class TVSearchAdapter extends RecyclerView.Adapter<TVSearchAdapter.TVSearchViewHolder> {
    private List<TVsearch>tVsearchList;
    private LayoutInflater layoutInflater;

    public TVSearchAdapter(List<TVsearch> tVsearchList) {
        this.tVsearchList = tVsearchList;
    }

    @NonNull
    @Override
    public TVSearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(layoutInflater==null){
            layoutInflater = layoutInflater.from(parent.getContext());

        }
        ItemSearchTvBinding tvSearchBingding = DataBindingUtil.inflate(
                layoutInflater,R.layout.item_search_tv,parent,false
        );
        return new TVSearchViewHolder(tvSearchBingding);
    }

    @Override
    public void onBindViewHolder(@NonNull TVSearchViewHolder holder, int position) {
        holder.bindTVSearch(tVsearchList.get(position));
    }

    @Override
    public int getItemCount() {
        return tVsearchList.size();
    }

    public static class TVSearchViewHolder extends RecyclerView.ViewHolder{
        private ItemSearchTvBinding itemSearchTvBinding;

        public TVSearchViewHolder(@NonNull ItemSearchTvBinding itemSearchTvBinding) {
            super(itemSearchTvBinding.getRoot());
            this.itemSearchTvBinding = itemSearchTvBinding;
        }

        public void bindTVSearch(TVsearch tVsearch){
            itemSearchTvBinding.setTvsearch(tVsearch);
            itemSearchTvBinding.executePendingBindings();
        }
    }
}
