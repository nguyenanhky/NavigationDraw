package com.example.searchmovie.models;

import com.google.gson.annotations.SerializedName;

public class TVshow {
    @SerializedName("id")
    private String id;

    @SerializedName("crew")
    private String crew;

    @SerializedName("fullTitle")
    private String fullTitle;

    @SerializedName("imDbRating")
    private String imDbRating;

    @SerializedName("image")
    private String image;

    @SerializedName("rank")
    private String rank;

    @SerializedName("rankUpDown")
    private String rankUpDown;

    @SerializedName("title")
    private String title;

    @SerializedName("year")
    private String year;

    // get and set

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCrew() {
        return crew;
    }

    public void setCrew(String crew) {
        this.crew = crew;
    }

    public String getFullTitle() {
        return fullTitle;
    }

    public void setFullTitle(String fullTitle) {
        this.fullTitle = fullTitle;
    }

    public String getImDbRating() {
        return imDbRating;
    }

    public void setImDbRating(String imDbRating) {
        this.imDbRating = imDbRating;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getRankUpDown() {
        return rankUpDown;
    }

    public void setRankUpDown(String rankUpDown) {
        this.rankUpDown = rankUpDown;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
