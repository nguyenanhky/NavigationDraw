package com.example.searchmovie.listeners;

import com.example.searchmovie.models.TVshow;

public interface TVShowsListener {
    void onTVShowclicked(TVshow tVshow);

}
